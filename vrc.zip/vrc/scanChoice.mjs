import EddystoneBeaconScanner from '@abandonware/eddystone-beacon-scanner'
var Choice = 0
const filter = [
    ''  // Put your ID in this string
]
EddystoneBeaconScanner.on('updated', (beacon) => {
    if ((parseInt(beacon.namespace, 16) == 99) && (parseInt(beacon.instance, 16) == 11)){
        Choice = 1
        //A
        //test  led.sync.setPixels(imageSmile)
    }
    else if((parseInt(beacon.namespace, 16) == 99) && (parseInt(beacon.instance, 16) == 22)) {
        Choice = 2
        //B
        //led.sync.setPixels(imageSad)
    }
    else if((parseInt(beacon.namespace, 16) == 99) && (parseInt(beacon.instance, 16) == 33)){ 
        Choice = 3
        //A+B
        //led.sync.setPixels(imageMid)
    }

    else if((parseInt(beacon.namespace, 16) == 99) && (parseInt(beacon.instance, 16) == 44)){
        Choice = 4
        //Emergency call
    }
    else if(beacon.distance > 10){
        Choice = 5
        //Notification to app
    }
});

EddystoneBeaconScanner.startScanning(true)
