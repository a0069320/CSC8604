import EddystoneBeaconScanner from '@abandonware/eddystone-beacon-scanner'
import led from 'sense-hat-led'

led.sync.clear()

const _ = [0,0,0]       // RGB fully off (=black)
const X = [255,255,255] // RGB fully on  (=white)
const imageSmile = [
    _,_,_,_,_,_,_,_,
    _,X,X,_,_,X,X,_,
    _,X,X,_,_,X,X,_,
    _,_,_,X,X,_,_,_,
    _,_,_,X,X,_,_,_,
    X,_,_,_,_,_,_,X,
    _,X,_,_,_,_,X,_,
    _,_,X,X,X,X,_,_,
]


const imageSad = [
    _,_,_,_,_,_,_,_,
    _,_,X,_,_,_,X,_,
    _,X,_,X,_,X,_,X,
    _,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,
    _,_,X,X,X,X,_,_,
    _,X,_,_,_,_,X,_,
    X,_,_,_,_,_,_,X,
    
]

const imageMid = [
    _,_,_,_,_,_,_,_,
    _,X,X,_,_,X,X,_,
    _,X,X,_,_,X,X,_,
    _,_,_,X,X,_,_,_,
    _,_,_,X,X,_,_,_,
    _,_,_,_,_,_,_,_,
    _,X,X,X,X,X,X,_,
    _,_,_,_,_,_,_,_,
    
]

const filter = [
    ''  // Put your ID in this string
]


EddystoneBeaconScanner.on('found', (beacon) =>{
    if (filter.join() && !filter.includes(beacon.id)) return
    //console.log('found: ' + beacon.id + ' - ' + beacon.connected);
    led.sync.setPixels(imageSmile)
});
EddystoneBeaconScanner.on('lost', (beacon) =>{
    if (filter.join() && !filter.includes(beacon.id)) return
    console.log('lost: ' + beacon.id + ' - ' + beacon.disconnected);
    led.sync.setPixels(imageSad)
    //Emergency call
});

EddystoneBeaconScanner.on('updated', (beacon) => {
    if (filter.join() && !filter.includes(beacon.id)) return
    console.log('updated: ' + beacon.id + ' - ' + beacon.distance)
    
});

EddystoneBeaconScanner.on('updated', (beacon) => {
    if (beacon.distance > 10){led.sync.setPixels(imageSad)
    //Notify user's family member or caregiver on website or app
    }
    else if(beacon.distance >= 5 && beacon.distance <= 10) {
        led.sync.setPixels(imageMid)
    }
    else{led.sync.setPixels(imageSmile)
    }
});


EddystoneBeaconScanner.startScanning(true)
