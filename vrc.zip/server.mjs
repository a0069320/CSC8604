//localhost:3000/website/VRC.html
import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'
import Choice from '@abandonware/eddystone-beacon-scanner'
//import Choice from './scanChoice'

const currentFolder = path.dirname(fileURLToPath(import.meta.url))
const app = express()

app.use('/', express.static(path.join(currentFolder, 'public')))

app.get('/', (req, res) => {
    res.send(Choice);
})

app.get('/VRC', (req, res) => {
    const filename = path.join(currentFolder, 'VRC.html')
    res.sendFile(filename)
    //console.log(Choice);
    //const filename1 =  path.join(currentFolder, (Choice < 2 ? 'Correct-answer.html' : 'Wrong-answer.html'));
    //res.sendFile(filename1)
})

app.get('/horse.ogg', (req, res) => {
    const filename = path.join(currentFolder, 'horse.ogg')
    res.sendFile(filename)
})

app.get('/Linda.jpg', (req, res) => {
    const filename = path.join(currentFolder, 'Linda.jpg')
    res.sendFile(filename)
})

app.get('/Mary.jpg', (req, res) => {
    const filename = path.join(currentFolder, 'Mary.jpg')
    res.sendFile(filename)
})

app.use('/website', express.static(currentFolder))

app.listen(3000, () => {
    console.log('Listening at http://localhost:3000/')
})
